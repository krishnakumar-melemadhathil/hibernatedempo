/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pinmicro.hibernatedemo.dao.impl;

import com.pinmicro.hibernatedemo.entities.Employee;
import com.pinmicro.hibernatedemo.helper.SessionFactory;
import org.hibernate.MappingException;
import com.pinmicro.hibernatedemo.dao.EmpDao;
import com.pinmicro.hibernatedemo.entities.Company;
import com.pinmicro.hibernatedemo.entities.enums.Status;
import org.hibernate.ObjectNotFoundException;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;

/**
 *
 * @author krishnakumar
 */
public class EmpDaoImpl implements EmpDao {

    public EmpDaoImpl() {
    }

    /**
     *
     * @param employee
     * @param cmpId
     */
    @Override
    public void createEmployee(Employee employee, Integer cmpId) {
        Session session = SessionFactory.getSessionFactory();
        try {
            session.beginTransaction();
            try{
                if(session.contains(session.load(Company.class, cmpId))){
                    Company company = (Company)session.load(Company.class, cmpId);
                    if(company.getStatus()==Status.ACTIVE){
                        employee.setCompany(company);
                        session.save(employee);
                        session.getTransaction().commit();
                        System.out.println("Employee added Employee ID : " + employee.getEmpId());
                    }
                    else{
                        System.out.println("Company is not existing..");
                    }
                }
            } catch (ObjectNotFoundException s ) {
                System.out.println(s.getMessage());
                System.out.println("Company is not existing..");
            }catch(ConstraintViolationException c){
                System.out.println(c.getMessage());
                System.out.println("Company not Found. \nPlease try again..");
            }
        } catch (MappingException s) {
            s.printStackTrace();
        }
    }

    /**
     *
     * @param empId
     * @param employee
     * @param cmpId
     */
    @Override
    public void updateEmployee(Integer empId, Employee employee, Integer cmpId) {
        org.hibernate.Session session = SessionFactory.getSessionFactory();
        try {
            session.beginTransaction();
            try {
                if (session.contains(session.load(Employee.class, empId)) && session.contains(session.load(Company.class, cmpId))) {
                    Employee e = (Employee) session.load(Employee.class, empId);
                    Company company = (Company)session.load(Company.class, cmpId);
                    e.setName(employee.getName());
                    e.setAge(employee.getAge());
                    e.setStatus(employee.getStatus());
                    if(company.getStatus()==Status.ACTIVE){
                        e.setCompany(company);
                        session.update(e);
                        session.getTransaction().commit();
                        session.close();
                        System.out.println("Employee updated, Employee Id : " + empId + " working at "+employee.getCompany().getName());
                    }
                    else{
                        System.out.println("Company is not existing..");
                    }
                } else {
                    System.out.println("Employee not Found, Try again..");
                }
            } catch (ObjectNotFoundException s) {
                System.out.println(s.getMessage());
                System.out.println("Employee not Found. \nPlease try again..");
            }catch(ConstraintViolationException c){
                System.out.println(c.getMessage());
                System.out.println("Company not Found. \nPlease try again..");
            }
        } catch (MappingException s) {
            s.printStackTrace();
        }
    }

    /**
     *
     * @param empId
     */
    @Override
    public void deleteEmployee(Integer empId) {
        org.hibernate.Session session = SessionFactory.getSessionFactory();
        try {
            session.beginTransaction();
            try {
                Employee e = (Employee) session.load(Employee.class, empId);
                session.delete(e);
                session.getTransaction().commit();
                session.close();
                System.out.println("Employee Deleted, Employee Id : " + empId);
            } catch (ObjectNotFoundException s) {
                System.out.println(s.getMessage());
                System.out.println("Employee not Found. \nPlease try again..");
            }
        } catch (MappingException s) {
            s.printStackTrace();
        }
    }

    /**
     *
     * @return
     */
    @Override
    public List<Employee> readAllEmployees() {
        List<Employee> list;
        try (org.hibernate.Session session = SessionFactory.getSessionFactory()) {
            list = session.createQuery("FROM Employee").list();
        }
        return list;
    }
}
