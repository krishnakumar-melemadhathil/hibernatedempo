/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pinmicro.hibernatedemo.service.impl;

import com.pinmicro.hibernatedemo.service.*;
import com.pinmicro.hibernatedemo.dao.*;
import java.util.*;
import com.pinmicro.hibernatedemo.entities.*;
import com.pinmicro.hibernatedemo.entities.enums.Status;

/**
 *
 * @author krishnakumar
 */
public class EmpServImpl implements EmpServ {

    private final EmpDao empDao;

    public EmpServImpl(EmpDao empDao) {
        this.empDao = empDao;
    }

    /**
     *
     */
    @Override
    public void createEmployee() {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter Name : ");
        String name = in.next();
        System.out.println("Enter Age : ");
        int age = in.nextInt();
        Status status = Status.ACTIVE;
        System.out.println("Enter Company ID : ");
        int compId = in.nextInt();
        Employee employee = new Employee(name, age, status);
        empDao.createEmployee(employee, compId);
    }

    /**
     *
     */
    @Override
    public void updateEmployee() {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter Employee Id to be updated :");
        Integer empId = in.nextInt();
        System.out.println("Enter details to be updated");
        System.out.println("Enter Name : ");
        String name = in.next();
        System.out.println("Enter Age : ");
        int age = in.nextInt();
        Status status = Status.ACTIVE;
        System.out.println("Enter Company ID : ");
        int compId = in.nextInt();
        Employee employee = new Employee(name, age, status);
        empDao.updateEmployee(empId, employee, compId);
    }

    /**
     *
     */
    @Override
    public void deleteEmployee() {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter the Employee ID to be deleted :");
        Integer empId = in.nextInt();
        empDao.deleteEmployee(empId);
    }

    /**
     *
     * @return
     */
    @Override
    public List<Employee> readAllEmployees() {
        return empDao.readAllEmployees();
    }
}
