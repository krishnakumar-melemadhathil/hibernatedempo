/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pinmicro.hibernatedemo.dao;

import com.pinmicro.hibernatedemo.entities.Employee;
import java.util.List;

/**
 *
 * @author krishnakumar
 */
public interface EmpDao {

    void createEmployee(Employee employee, Integer compId);

    void updateEmployee(Integer empId, Employee employee, Integer cmpId);

    void deleteEmployee(Integer empId);

    List<Employee> readAllEmployees();
}
