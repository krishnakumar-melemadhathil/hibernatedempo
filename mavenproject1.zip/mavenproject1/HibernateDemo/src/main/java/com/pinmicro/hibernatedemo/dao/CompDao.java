/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pinmicro.hibernatedemo.dao;

import com.pinmicro.hibernatedemo.entities.Company;
import java.util.List;

/**
 *
 * @author krishnakumar
 */
public interface CompDao {

    void addComp(Company company);

    void updateComp(Integer compId, Company company);

    void deleteComp(Integer compId);

    List<Company> readAll();
}
