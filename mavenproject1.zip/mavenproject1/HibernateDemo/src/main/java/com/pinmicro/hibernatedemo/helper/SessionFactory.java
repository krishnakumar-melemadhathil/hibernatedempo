/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pinmicro.hibernatedemo.helper;

import org.hibernate.cfg.Configuration;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import com.pinmicro.hibernatedemo.entities.*;

/**
 *
 * @author krishnakumar
 */
public class SessionFactory {

    public static org.hibernate.Session getSessionFactory() {
        Configuration configuration = new Configuration().configure();
        configuration.addAnnotatedClass(Employee.class);
        configuration.addAnnotatedClass(Company.class);
//        configuration.addResource("com.pinmicro.hibernatedemo.helper.hibernate.hbm.xml");
        StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder()
                .applySettings(configuration.getProperties());
//        configuration.getProperties()
//                .entrySet()
//                .stream()
//                .map(pro -> pro.getKey() + "->" + pro.getValue())
//                .forEach(System.out::println);
        org.hibernate.SessionFactory sessionFactory = configuration
                .buildSessionFactory(builder.build());
//        sessionFactory.getMetamodel().
        org.hibernate.Session session = sessionFactory.openSession();
        return session;
    }

}
