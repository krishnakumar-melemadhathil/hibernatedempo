/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pinmicro.hibernatedemo.service;

import com.pinmicro.hibernatedemo.entities.*;
import java.util.*;

/**
 *
 * @author krishnakumar
 */
public interface EmpServ {

    void createEmployee();

    void updateEmployee();

    void deleteEmployee();

    List<Employee> readAllEmployees();
}
