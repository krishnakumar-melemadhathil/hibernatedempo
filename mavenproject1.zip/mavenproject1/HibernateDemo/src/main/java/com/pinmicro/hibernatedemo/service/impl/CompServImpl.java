/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pinmicro.hibernatedemo.service.impl;

import com.pinmicro.hibernatedemo.dao.CompDao;
import com.pinmicro.hibernatedemo.entities.Company;
import com.pinmicro.hibernatedemo.entities.enums.Status;
import com.pinmicro.hibernatedemo.service.CompServ;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author krishnakumar
 */
public class CompServImpl implements CompServ {

    private final CompDao compDao;

    public CompServImpl(CompDao compDao) {
        this.compDao = compDao;
    }

    /**
     *
     */
    @Override
    public void addComp() {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter Name : ");
        String name = in.next();
        Status status = Status.ACTIVE;
        Company company = new Company(name, status);
        compDao.addComp(company);
        System.out.println("Company added Company ID : " + company.getCompanyId());
    }

    /**
     *
     */
    @Override
    public void updateComp() {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter Company Id to be updated :");
        Integer compId = in.nextInt();
        System.out.println("Enter Name : ");
        String name = in.next();
        Status status = Status.ACTIVE;
        Company company = new Company(name, status);
        compDao.updateComp(compId, company);
    }

    /**
     *
     */
    @Override
    public void deleteComp() {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter the Company ID to be deleted :");
        Integer compId = in.nextInt();
        compDao.deleteComp(compId);
    }

    /**
     *
     * @return
     */
    @Override
    public List<Company> readAll() {
        return compDao.readAll();
    }
}
