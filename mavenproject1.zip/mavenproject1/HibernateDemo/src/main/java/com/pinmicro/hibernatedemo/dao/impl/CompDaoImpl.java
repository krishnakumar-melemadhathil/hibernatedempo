/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pinmicro.hibernatedemo.dao.impl;

import com.pinmicro.hibernatedemo.dao.CompDao;
import com.pinmicro.hibernatedemo.entities.Company;
import com.pinmicro.hibernatedemo.entities.enums.Status;
import com.pinmicro.hibernatedemo.helper.SessionFactory;
import java.util.List;
import org.hibernate.MappingException;
import org.hibernate.ObjectNotFoundException;

/**
 *
 * @author krishnakumar
 */
public class CompDaoImpl implements CompDao {

    public CompDaoImpl() {
    }

    /**
     *
     * @param company
     */
    @Override
    public void addComp(Company company) {
        org.hibernate.Session session = SessionFactory.getSessionFactory();
        try {
            session.beginTransaction();
            session.save(company);
            session.getTransaction().commit();
        } catch (MappingException s) {
            s.printStackTrace();
        }
    }

    /**
     *
     * @param compId
     * @param company
     */
    @Override
    public void updateComp(Integer compId, Company company) {
        org.hibernate.Session session = SessionFactory.getSessionFactory();
        try {
            session.beginTransaction();
            try {
                if (session.contains(session.load(Company.class, compId))) {
                    Company c = (Company) session.load(Company.class, compId);
                    c.setName(company.getName());
                    c.setStatus(company.getStatus());
                    session.update(c);
                    session.getTransaction().commit();
                    session.close();
                    System.out.println("Company updated, Company Id : " + compId);
                } else {
                    System.out.println("Company not Found, Try again..");
                }
            } catch (ObjectNotFoundException s) {
                System.out.println(s.getMessage());
                System.out.println("Company not Found. \nPlease try again..");
            }
        } catch (MappingException s) {
            s.printStackTrace();
        }
    }

    /**
     *
     * @param compId
     */
    @Override
    public void deleteComp(Integer compId) {
        org.hibernate.Session session = SessionFactory.getSessionFactory();
        try {
            session.beginTransaction();
            try {
                Company c = (Company) session.load(Company.class, compId);
                c.setStatus(Status.DELETED);
                session.getTransaction().commit();
                session.close();
                System.out.println("Company Deleted, Company Id : " + compId);
            } catch (ObjectNotFoundException s) {
                System.out.println(s.getMessage());
                System.out.println("Company not Found. \nPlease try again..");
            }
        } catch (MappingException s) {
            s.printStackTrace();
        }
    }

    /**
     *
     * @return
     */
    @Override
    public List<Company> readAll() {
        List<Company> list;
        try (org.hibernate.Session session = SessionFactory.getSessionFactory()) {
            list = session.createQuery("FROM Company").list();
        }
        return list;
    }

}
