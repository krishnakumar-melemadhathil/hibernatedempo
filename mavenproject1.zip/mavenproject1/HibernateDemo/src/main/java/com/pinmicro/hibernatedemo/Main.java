/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pinmicro.hibernatedemo;

import com.pinmicro.hibernatedemo.dao.impl.CompDaoImpl;
import com.pinmicro.hibernatedemo.dao.impl.EmpDaoImpl;
import com.pinmicro.hibernatedemo.service.impl.EmpServImpl;
import java.util.*;
import com.pinmicro.hibernatedemo.entities.*;
import com.pinmicro.hibernatedemo.service.*;
import com.pinmicro.hibernatedemo.service.impl.CompServImpl;

/**
 *
 * @author krishnakumar
 */
public class Main {

    private final EmpServ empServ;
    private final CompServ compServ;

    public Main(EmpServ empServ, CompServ compServ) {
        this.empServ = empServ;
        this.compServ = compServ;
    }

    public static void main(String[] args) {
        new Main(new EmpServImpl(new EmpDaoImpl()), new CompServImpl(new CompDaoImpl())).empManager();
    }

    private void empManager() {
        Scanner in = new Scanner(System.in);
        while (true) {
            System.out.println("Choose an option");
            System.out.println("1.Add Employee");
            System.out.println("2.Update Employee data");
            System.out.println("3.Delete Employee");
            System.out.println("4.View all Employees");
            System.out.println("5.Company Manager");
            System.out.println("6.Exit");
            int opt = in.nextInt();
            switch (opt) {
                case 1:
                    empServ.createEmployee();
                    break;
                case 2:
                    empServ.updateEmployee();
                    break;
                case 3:
                    empServ.deleteEmployee();
                    break;
                case 4:
                    readAllEmployees();
                    break;
                case 5:
                    compManager();
                    break;
                case 6:
                    System.exit(0);
                    break;
            }
        }
    }

    private void compManager() {
        Scanner in = new Scanner(System.in);
        while (true) {
            System.out.println("Choose an option");
            System.out.println("1.Add Company");
            System.out.println("2.Update Company data");
            System.out.println("3.Delete Company");
            System.out.println("4.View all Companies");
            System.out.println("5.Employee Manager");
            System.out.println("6.Exit");
            int opt = in.nextInt();
            switch (opt) {
                case 1:
                    compServ.addComp();
                    break;
                case 2:
                    compServ.updateComp();
                    break;
                case 3:
                    compServ.deleteComp();
                    break;
                case 4:
                    readAll();
                    break;
                case 5:
                    empManager();
                    break;
                case 6:
                    System.exit(0);
                    break;
            }
        }
    }

    private void readAllEmployees() {
        List<Employee> list = empServ.readAllEmployees();
        Employee employee;
        long l = list.stream().count();
        System.out.println("\n\n");
        System.out.println("Employee Details");
        System.out.println("****************\n");
        for (int i = 0; i < l; ++i) {
            employee = list.get(i);
            System.out.println(i + 1 + ") Employee ID : " + employee.getEmpId());
            System.out.print("Name : " + employee.getName());
            System.out.print(", Age : " + employee.getAge());
            System.out.print(", Status : " + employee.getStatus());
            System.out.println(", Company : " + employee.getCompany().getName() + "\n");
        }
    }

    private void readAll() {
        List<Company> list = compServ.readAll();
        Company company;
        long l = list.stream().count();
        System.out.println("\n\n");
        System.out.println("Company Details");
        System.out.println("****************\n");
        for (int i = 0; i < l; ++i) {
            company = list.get(i);
            System.out.println(i + 1 + ") Company ID : " + company.getCompanyId());
            System.out.print("Name : " + company.getName());
            System.out.println(", Status : " + company.getStatus() + "\n");
        }
    }
}
